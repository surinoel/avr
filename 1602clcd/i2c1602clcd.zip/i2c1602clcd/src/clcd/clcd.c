﻿/*
 * clcd.c
 *
 * Created: 2019-07-06 오후 3:07:03
 *  Author: user
 */ 

#include "clcd.h"
#include "uart.h"

uint8_t I2C_addr_PCF8574 = (0x20 << 1);

void i2c_lcd_init(void)
{
	printf("Before Connect... \r\n");	
	i2c_init();
	_delay_ms(50);
	while(!i2c_start(I2C_addr_PCF8574));
	i2c_stop();
	printf("Connect Ok\r\n");
	i2c_lcd_command_8(0x30); _delay_ms(5);
	i2c_lcd_command_8(0x30); _delay_ms(1);
	i2c_lcd_command_8(0x30); _delay_ms(1);
	i2c_lcd_command_8(0x20); _delay_ms(1);
	
	printf("Before Initialize... \r\n");	
	i2c_lcd_command(0x28); _delay_us(50);	// function set(4-bit, 2 line, 5x7 dot)		i2c_lcd_command(0x0C); _delay_us(50);	// display control(display ON, cursor OFF)
	i2c_lcd_command(0x0C); _delay_us(50);	// display control(display ON, cursor OFF)
	i2c_lcd_command(0x01); _delay_ms(2);	// clear display
	i2c_lcd_command(0x06); _delay_us(50); 	// entry mode set(increment, not shift)
	printf("Connect Ok\r\n");	
}

void i2c_lcd_command_8(uint8_t command)
{
	uint8_t c_buf[2];
	
	c_buf[0] = command | 0x10;
	c_buf[1] = c_buf[0] & 0xEF;	
	
	while(!i2c_transmit(I2C_addr_PCF8574, c_buf, 2));
}

void i2c_lcd_command(uint8_t command)
{
	uint8_t c_buf[4];
	
	c_buf[0] = (command >> 4) | 0x10;
	c_buf[1] = c_buf[0] & 0xEF;
	
	c_buf[2] = (command & 0x0F) | 0x10;
	c_buf[3] = c_buf[2] & 0xEF;
	
	while(!i2c_transmit(I2C_addr_PCF8574, c_buf, 4));
}

void i2c_lcd_data(uint8_t data)
{
	uint8_t d_buf[4];
	
	d_buf[0] = (data >> 4) | 0x50;
	d_buf[1] = d_buf[0] & 0xEF;
	
	d_buf[2] = (data & 0x0F) | 0x50;
	d_buf[3] = d_buf[2] & 0xEF;
	
	while(!i2c_transmit(I2C_addr_PCF8574, d_buf, 4));
}

void i2c_lcd_goto_XY(uint8_t row, uint8_t col)
{
	col %= 16;
	row %= 2;
	
	uint8_t address = (0x40 * row) + col;
	uint8_t command = 0x80 + address;
	
	i2c_lcd_command(command);
}

void i2c_lcd_string(uint8_t row, uint8_t col, char string[])
{
	i2c_lcd_goto_XY(row, col);
	for(int i=0; string[i] != '\0'; i++) {
		i2c_lcd_data(string[i]);
	}
}