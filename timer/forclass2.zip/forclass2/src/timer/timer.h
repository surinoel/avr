﻿/*
 * timer.h
 *
 * Created: 2019-06-09 오후 2:53:29
 *  Author: yeong
 */ 

#ifndef TIMER_H_
#define TIMER_H_

#include <avr/io.h>
#include <avr/interrupt.h>

void delay_ms(int mstime);

#endif /* TIMER_H_ */