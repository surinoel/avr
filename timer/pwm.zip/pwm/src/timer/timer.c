﻿/*
 * timer.c
 *
 * Created: 2019-06-09 오후 3:28:47
 *  Author: yeong
 */ 

 #include "timer.h"

 void timer1_pwm_init(void) 
 {
	TCCR1A |= (1<<WGM11) | (1<<COM1A1);
	TCCR1B |= (1<<WGM13) | (1<<WGM12) | (1<<CS10);
	DDRB |= (1<<5);
	ICR1 = 5000;
 }